import mongoose from 'mongoose';

const siteSettingSchema = new mongoose.Schema({
  key: { type: String, required: true, unique: true },
  value: { type: mongoose.Schema.Types.Mixed, required: true }
}, { timestamps: true });

export const SiteSetting = mongoose.model('SiteSetting', siteSettingSchema);
